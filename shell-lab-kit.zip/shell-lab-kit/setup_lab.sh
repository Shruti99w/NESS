#!/bin/bash
# setup_lab.sh - creates (or resets) the practice lab at ~/de-shell-lab
# A reset clears the data folders but keeps anything in ~/de-shell-lab/scripts
# Run with: bash setup_lab.sh

LAB="$HOME/de-shell-lab"

if [ -d "$LAB" ]; then
    echo "Existing lab found - resetting data folders (scripts/ is kept)"
    for d in raw staging processed archive logs backup_raw; do
        rm -rf -- "${LAB:?}/$d"
    done
fi

mkdir -p "$LAB"/{raw,staging,processed,archive,logs,scripts}
cd "$LAB" || exit 1

cat > raw/sales_2026-10-01.csv <<'CSV'
order_id,order_date,region,product,quantity,unit_price
1001,2026-10-01,North,Laptop,2,55000
1002,2026-10-01,South,Mouse,10,450
1003,2026-10-01,East,Monitor,3,12000
1004,2026-10-01,West,Keyboard,5,1500
1005,2026-10-01,North,Mouse,4,450
CSV

cat > raw/sales_2026-10-02.csv <<'CSV'
order_id,order_date,region,product,quantity,unit_price
1006,2026-10-02,South,Laptop,1,55000
1007,2026-10-02,East,Mouse,6,450
1008,2026-10-02,North,Monitor,2,12000
CSV

# An empty file - this happens in real pipelines more often than you would like
touch raw/sales_2026-10-03.csv

cat > logs/etl_job.log <<'LOG'
2026-10-01 01:00:01 INFO  Job started
2026-10-01 01:00:05 INFO  Extracted 5 rows from sales_2026-10-01.csv
2026-10-01 01:00:06 ERROR Connection to warehouse timed out
2026-10-01 01:02:06 INFO  Retry 1 succeeded
2026-10-01 01:02:10 INFO  Loaded 5 rows
2026-10-02 01:00:01 INFO  Job started
2026-10-02 01:00:04 ERROR File sales_2026-10-02.csv has bad header
2026-10-02 01:00:04 INFO  Job finished with errors
LOG

echo "Lab ready at $LAB"
ls -R "$LAB"
