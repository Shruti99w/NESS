SHELL SCRIPTING FOR DATA ENGINEERS - LAB KIT
Tested on Ubuntu 24.04 LTS, GNU bash 5.2

CONTENTS
  setup_lab.sh     Creates the practice lab at ~/de-shell-lab.
                   Running it again resets the sample data but keeps ~/de-shell-lab/scripts.
  scripts/         Every demo script from the lab guide, plus the capstone ingest.sh
  solutions/       Exercise solutions (inspect, file_stats, count_errors, retry, daily_summary)

QUICK START
  sudo apt update && sudo apt install -y unzip bc     (only if missing)
  unzip shell-lab-kit.zip -d ~
  bash ~/shell-lab-kit/setup_lab.sh
  cp ~/shell-lab-kit/scripts/*.sh ~/de-shell-lab/scripts/
  chmod +x ~/de-shell-lab/scripts/*.sh

TROUBLESHOOTING
  "bad interpreter: /bin/bash^M"  The file was saved with Windows line endings. Fix:
                                  sed -i 's/\r$//' ~/de-shell-lab/scripts/*.sh
  "Permission denied"             chmod +x <script>.sh   (or run it with: bash <script>.sh)
  "command not found" for a script  Prefix with ./  ->  ./hello.sh
