#!/bin/bash
# ingest.sh - mini ingestion job (capstone)
set -uo pipefail     # stop on unset variables; catch failures inside pipes

DATA_DIR=${DATA_DIR:-$HOME/de-shell-lab}
run_date=$(date +%Y-%m-%d)
log_file="$DATA_DIR/logs/ingest_${run_date}.log"
expected_header="order_id,order_date,region,product,quantity,unit_price"

processed=0; skipped=0; rejected=0; total_rows=0

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" | tee -a "$log_file"
}

mkdir -p "$DATA_DIR"/{staging,archive/rejected,logs}
log "INFO  Ingestion started. DATA_DIR=$DATA_DIR"

for file in "$DATA_DIR"/raw/*.csv; do
    [ -e "$file" ] || { log "WARN  No CSV files found"; break; }
    name=$(basename "$file")

    if [ ! -s "$file" ]; then
        log "WARN  $name is empty - skipped"
        skipped=$(( skipped + 1 ))
        continue
    fi

    header=$(head -n 1 "$file")
    if [ "$header" != "$expected_header" ]; then
        log "ERROR $name has an unexpected header - rejected"
        mv "$file" "$DATA_DIR/archive/rejected/"
        rejected=$(( rejected + 1 ))
        continue
    fi

    rows=$(tail -n +2 "$file" | wc -l)
    cp "$file" "$DATA_DIR/staging/" && mv "$file" "$DATA_DIR/archive/"
    total_rows=$(( total_rows + rows ))
    processed=$(( processed + 1 ))
    log "INFO  $name loaded to staging ($rows rows)"
done

log "INFO  Summary: processed=$processed skipped=$skipped rejected=$rejected rows=$total_rows"

if [ "$rejected" -gt 0 ]; then
    exit 1
fi
exit 0
