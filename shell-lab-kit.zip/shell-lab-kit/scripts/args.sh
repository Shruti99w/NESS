#!/bin/bash
# args.sh - script arguments
echo "Script: $0"
echo "You passed $# arguments: $@"
echo "First one: $1"
