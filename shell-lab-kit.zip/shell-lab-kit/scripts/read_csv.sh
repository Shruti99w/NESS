#!/bin/bash
# read_csv.sh - while loop reading a CSV line by line
file=~/de-shell-lab/raw/sales_2026-10-01.csv

tail -n +2 "$file" | while IFS=',' read -r order_id order_date region product qty price; do
    line_total=$(( qty * price ))
    echo "Order $order_id | $region | $product | total = $line_total"
done
