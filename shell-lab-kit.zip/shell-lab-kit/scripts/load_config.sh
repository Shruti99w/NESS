#!/bin/bash
# load_config.sh - configuration from environment variables
DATA_DIR=${DATA_DIR:-$HOME/de-shell-lab}
ENV_NAME=${ENV_NAME:-dev}

echo "Environment : $ENV_NAME"
echo "Data folder : $DATA_DIR"
