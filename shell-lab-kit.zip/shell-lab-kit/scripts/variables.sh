#!/bin/bash
# variables.sh - declaring and using variables

source_dir="$HOME/de-shell-lab/raw"   # no spaces around =
file_prefix="sales"
max_retries=3

echo "Reading from: $source_dir"
echo "Prefix: ${file_prefix}_"              # braces separate the name from text
echo "Retries allowed: $max_retries"

run_date=${1:-$(date +%Y-%m-%d)}            # first argument, or today if none given
echo "Processing date: $run_date"
