#!/bin/bash
# skip_and_stop.sh - continue and break
for file in ~/de-shell-lab/raw/*.csv; do
    name=$(basename "$file")

    if [ ! -s "$file" ]; then
        echo "SKIP  $name (empty)"
        continue
    fi

    if [[ "$name" == *bad* ]]; then
        echo "STOP  $name looks corrupt - halting run"
        break
    fi

    echo "OK    $name"
done
