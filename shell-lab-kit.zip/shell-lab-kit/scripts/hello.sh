#!/bin/bash
# hello.sh - first script
echo "Hello, data engineer"
echo "Today is $(date +%Y-%m-%d)"
