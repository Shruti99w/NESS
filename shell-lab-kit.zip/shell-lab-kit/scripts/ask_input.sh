#!/bin/bash
# ask_input.sh - reading user input with read

read -r -p "Enter the region to filter: " region
echo "You chose: $region"

read -r -p "Enter source and target folders: " src tgt   # two values in one line
echo "Source=$src  Target=$tgt"

read -r -s -p "Enter DB password: " db_pass   # -s hides typing
echo
echo "Password length: ${#db_pass} characters"

if ! read -r -t 5 -p "Continue? (y/n) [auto-yes in 5s]: " answer; then
    echo                                     # move to a new line after a timeout
fi
answer=${answer:-y}
echo "Answer: $answer"
