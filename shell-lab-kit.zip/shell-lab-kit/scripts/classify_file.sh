#!/bin/bash
# classify_file.sh - if / elif / else on row counts
file=$1

if [ -z "$file" ]; then
    echo "Usage: $0 <csv_file>"
    exit 1
fi

if [ ! -f "$file" ]; then
    echo "File not found: $file"
    exit 1
fi

rows=$(tail -n +2 "$file" | wc -l)

if [ "$rows" -eq 0 ]; then
    echo "$file: EMPTY - flag for investigation"
elif [ "$rows" -lt 5 ]; then
    echo "$file: LOW volume ($rows rows)"
else
    echo "$file: OK ($rows rows)"
fi
