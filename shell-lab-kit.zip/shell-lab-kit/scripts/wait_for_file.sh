#!/bin/bash
# wait_for_file.sh - until loop waiting for an upstream file
target=~/de-shell-lab/raw/trigger.done
attempt=0
max_attempts=5

until [ -f "$target" ] || [ "$attempt" -ge "$max_attempts" ]; do
    attempt=$(( attempt + 1 ))
    echo "Waiting for $target (attempt $attempt/$max_attempts)"
    sleep 2
done

if [ -f "$target" ]; then
    echo "File arrived - starting load"
else
    echo "Timed out - upstream file missing"
    exit 1
fi
