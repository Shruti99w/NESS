#!/bin/bash
# preflight.sh - file and folder checks before a load
src=~/de-shell-lab/raw
tgt=~/de-shell-lab/staging

[ -d "$src" ] || { echo "Source folder missing: $src"; exit 1; }
[ -d "$tgt" ] || mkdir -p "$tgt"
[ -w "$tgt" ] || { echo "Cannot write to $tgt"; exit 1; }

for file in "$src"/*.csv; do
    [ -e "$file" ] || { echo "No CSV files in $src"; break; }
    if [ ! -r "$file" ]; then
        echo "UNREADABLE $(basename "$file")"
    elif [ ! -s "$file" ]; then
        echo "EMPTY      $(basename "$file")"
    else
        echo "READY      $(basename "$file")"
    fi
done
