#!/bin/bash
# Exercise 4a - count_errors.sh
info=0; error=0
while read -r line; do
    if [[ "$line" == *" INFO "* ]]; then
        info=$(( info + 1 ))
    elif [[ "$line" == *" ERROR "* ]]; then
        error=$(( error + 1 ))
    fi
done < ~/de-shell-lab/logs/etl_job.log
echo "INFO lines : $info"
echo "ERROR lines: $error"
