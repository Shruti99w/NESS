#!/bin/bash
# Exercise 4b - retry.sh <folder>
target=$1
success=0
for attempt in 1 2 3; do
    if ls "$target" > /dev/null 2>&1; then
        echo "Attempt $attempt: success"
        success=1
        break
    fi
    echo "Attempt $attempt: failed, retrying..."
    sleep 1
done
[ "$success" -eq 1 ] || { echo "Failed after 3 attempts"; exit 1; }
