#!/bin/bash
# Exercise 5 - daily_summary.sh
base=~/de-shell-lab
today=$(date +%Y-%m-%d)
out="$base/logs/summary_${today}.txt"
err="$base/logs/summary_errors.txt"

total=0; empty=0
for f in "$base"/raw/*.csv; do
    [ -e "$f" ] || continue
    total=$(( total + 1 ))
    [ -s "$f" ] || empty=$(( empty + 1 ))
done

errors=$(grep ERROR "$base/logs/etl_job.log" 2>> "$err" | wc -l)

{
    echo "Summary for $today"
    echo "CSV files in raw : $total"
    echo "Empty CSV files  : $empty"
    echo "ERROR log lines  : $errors"
} > "$out" 2>> "$err"

cat "$out"
