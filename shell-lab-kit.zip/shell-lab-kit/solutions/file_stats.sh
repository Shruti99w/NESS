#!/bin/bash
# Exercise 3 - file_stats.sh <csv_file>
file=$1
[ -f "$file" ] || { echo "Usage: $0 <csv_file>"; exit 1; }
rows=$(tail -n +2 "$file" | wc -l)
cols=$(head -n 1 "$file" | tr ',' '\n' | wc -l)
echo "File    : $(basename "$file")"
echo "Rows    : $rows"
echo "Columns : $cols"
echo "Checked : $(date +%Y-%m-%d)"
