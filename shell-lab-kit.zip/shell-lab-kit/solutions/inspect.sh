#!/bin/bash
# Exercise 2 - inspect.sh
file=~/de-shell-lab/raw/sales_2026-10-01.csv
head -n 3 "$file"
wc -l "$file"
